package com.mingze.jsketch;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.Log;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

public class Board extends View implements Observer
{
    private Model model;
    private ImageView imageView;
    private Bitmap bitmap;
    private Canvas canvas;
    private Paint paint;
    private int w;
    private int h;
    private float start_x;
    private float start_y;
    private ScaleGestureDetector SGD;
    private float scaleFactor = 1.f;
    private float scaleFactorOld = 1.f;

    public Board(Context context, Model m, ImageView iv)
    {
        super(context);
        this.model = m;
        model.addObserver(this);
        imageView = iv;
        SGD = new ScaleGestureDetector(context, new ScaleListener());
   }

    public void setCanvas(int height, int width){
        w = width;
        h = height;
        int f = 0;
        bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        canvas = new Canvas(bitmap);
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        imageView.setOnTouchListener(new OnTouchListener() {
                                         @Override
                                         public boolean onTouch(View v, MotionEvent event) {
                                             SGD.onTouchEvent(event);
                                             float finger_x;
                                             float finger_y;
                                             int f = 0;
                                             Log.d("scalefactor", " "+scaleFactor);
                                             if(model.getTool()==0){ //if upon select
                                                 switch(event.getAction()) {
                                                     case MotionEvent.ACTION_DOWN:
                                                         finger_x = event.getX();
                                                         finger_y = event.getY();
                                                         f = find(finger_x, finger_y, false, false, false);
                                                         if(f==1){
                                                             model.setSelectColor(1);
                                                         }else{
                                                             model.setSelectColor(2);
                                                         }
                                                         break;
                                                     case MotionEvent.ACTION_MOVE:
                                                         finger_x = event.getX();
                                                         finger_y = event.getY();
                                                         f = find(finger_x, finger_y, false, true, false);
                                                         if(f==1){
                                                             model.setSelectColor(1);
                                                         }else{
                                                             model.setSelectColor(2);
                                                         }
                                                         break;
                                                 }
                                             }else if(model.getTool()==1){ //if upon erase
                                                 switch(event.getAction()) {
                                                     case MotionEvent.ACTION_DOWN:
                                                         finger_x = event.getX();
                                                         finger_y = event.getY();
                                                         find(finger_x, finger_y, false, false, true);
                                                         break;
                                                     case MotionEvent.ACTION_MOVE:
                                                         finger_x = event.getX();
                                                         finger_y = event.getY();
                                                         find(finger_x, finger_y, false, false, true);
                                                         break;
                                                     case MotionEvent.ACTION_UP:
                                                         finger_x = event.getX();
                                                         finger_y = event.getY();
                                                         find(finger_x, finger_y, true, false, true);
                                                         break;
                                                 }

                                             }else{
                                                 switch(event.getAction()){
                                                     case MotionEvent.ACTION_DOWN:
                                                         start_x = event.getX();
                                                         start_y = event.getY();
                                                         break;
                                                     case MotionEvent.ACTION_MOVE:
                                                         finger_x = event.getX();
                                                         finger_y = event.getY();
                                                         draw(finger_x, finger_y);
                                                         break;
                                                     case MotionEvent.ACTION_UP:
                                                         finger_x = event.getX();
                                                         finger_y = event.getY();
                                                         addShape(finger_x, finger_y);
                                                         start_x = -1;
                                                         start_y = -1;
                                                         break;
                                                 }
                                             }
                                             return true;
                                         }
                                     }
        );
    }

    //move the top layer selected shape
    public void move(float x, float y){
        ArrayList<ArrayList<Float>> list = model.getList();
        int length = list.size();
        ArrayList<Float> elem = list.get(length-1);
        int tool = elem.get(0).intValue();
        int color = elem.get(1).intValue();
        if(tool==2){ //rect
            float x1 = elem.get(2);
            float y1 = elem.get(3);
            float x2 = elem.get(4);
            float y2 = elem.get(5);
            list.remove(length-1);
            ArrayList<Float> shape = new ArrayList<Float>();
            shape.add((float) tool);
            shape.add((float) color);
            float xdiff = Math.abs(x1-x2)/2;
            float ydiff = Math.abs(y1-y2)/2;
            shape.add(x-xdiff);
            shape.add(y-ydiff);
            shape.add(x+xdiff);
            shape.add(y+ydiff);
            list.add(shape);
        }else if(tool==3) {//circle
            float radius = elem.get(4);
            list.remove(length-1);
            ArrayList<Float> shape = new ArrayList<Float>();
            shape.add((float) tool);
            shape.add((float) color);
            shape.add(x);
            shape.add(y);
            shape.add(radius);
            list.add(shape);
        }else if(tool==4) {//line
            float x1 = elem.get(2);
            float y1 = elem.get(3);
            float x2 = elem.get(4);
            float y2 = elem.get(5);
            list.remove(length-1);
            ArrayList<Float> shape = new ArrayList<Float>();
            float xdiff = Math.abs(x1-x2)/2;
            float ydiff = Math.abs(y1-y2)/2;
            shape.add((float) tool);
            shape.add((float) color);
            if((x1>=x2)&&(y1>=y2)){
                shape.add(x+xdiff);
                shape.add(y+ydiff);
                shape.add(x-xdiff);
                shape.add(y-ydiff);
            }else if((x1<=x2)&&(y1>=y2)){
                shape.add(x-xdiff);
                shape.add(y+ydiff);
                shape.add(x+xdiff);
                shape.add(y-ydiff);
            }else if((x1>=x2)&&(y1<=y2)){
                shape.add(x+xdiff);
                shape.add(y-ydiff);
                shape.add(x-xdiff);
                shape.add(y+ydiff);
            }else if((x1<=x2)&&(y1<=y2)){
                shape.add(x-xdiff);
                shape.add(y-ydiff);
                shape.add(x+xdiff);
                shape.add(y+ydiff);
            }
            list.add(shape);
        }

        canvas.drawColor(Color.WHITE);
        redraw();
    }

    //change colour
    public void changeColor(int color){
        ArrayList<ArrayList<Float>> list = model.getList();
        int length = list.size();
        if(length==0){
            canvas.drawColor(Color.WHITE);
            redraw();
            return;
        }
        ArrayList<Float> elem = list.get(length-1);
        int tool = elem.get(0).intValue();
        if(tool==2){ //rect
            float x1 = elem.get(2);
            float y1 = elem.get(3);
            float x2 = elem.get(4);
            float y2 = elem.get(5);
            list.remove(length-1);
            ArrayList<Float> shape = new ArrayList<Float>();
            shape.add((float) tool);
            shape.add((float) color);
            shape.add(x1);
            shape.add(y1);
            shape.add(x2);
            shape.add(y2);
            list.add(shape);
        }else if(tool==3) {//circle
            float radius = elem.get(4);
            float x = elem.get(2);
            float y = elem.get(3);
            list.remove(length-1);
            ArrayList<Float> shape = new ArrayList<Float>();
            shape.add((float) tool);
            shape.add((float) color);
            shape.add(x);
            shape.add(y);
            shape.add(radius);
            list.add(shape);
        }else if(tool==4) {//line
            float x1 = elem.get(2);
            float y1 = elem.get(3);
            float x2 = elem.get(4);
            float y2 = elem.get(5);
            list.remove(length-1);
            ArrayList<Float> shape = new ArrayList<Float>();
            shape.add((float) tool);
            shape.add((float) color);
            shape.add(x1);
            shape.add(y1);
            shape.add(x2);
            shape.add(y2);
            list.add(shape);
        }
        canvas.drawColor(Color.WHITE);
        redraw();
    }


    //find the shape being selected from list of shapes by calculation
    public int find(float x, float y, boolean isErase, boolean isMove, boolean eraseAct){
        ArrayList<ArrayList<Float>> list = model.getList();
        int length = list.size();

        for(int i =length-1; i>=0; i--){
            ArrayList<Float> elem = list.get(i);
            int tool = elem.get(0).intValue();
            int color = elem.get(1).intValue();
            if(tool==3){ //circle
                float center_x = elem.get(2);
                float center_y = elem.get(3);
                float radius = elem.get(4);
                float dist = (float) Math.sqrt(Math.pow((x-center_x),2)+Math.pow((y-center_y),2));
                if(dist<=radius){
                    if(!eraseAct){
                        model.setSelected(true);
                    }

                    ArrayList<Float> shape = new ArrayList<Float>();
                    list.remove(i);
                    if (!isErase) {
                        shape.add((float) tool);
                        shape.add((float) color);
                        shape.add(center_x);
                        shape.add(center_y);


                        if(scaleFactor==1){
                            scaleFactorOld=1;
                        }else if(Math.abs(scaleFactorOld - scaleFactor)>0.01){
                            float factor = scaleFactor-scaleFactorOld;
                            if(factor>1){
                                factor=1;
                            }else if(factor<-0.5){
                                factor= (float) -0.5;
                            }
                           // Log.d("scalefactor----->factor", ""+factor);
                            radius *= 1+ factor;

                            scaleFactorOld = scaleFactor;
                        }
                        shape.add(radius);
                        list.add(shape);
                    }
                    if(isMove){
                        move(x, y);
                    }else{
                        canvas.drawColor(Color.WHITE);
                        redraw();
                    }
                    return 1;

                }
            }else if(tool==2){ //rect
                float x1 = elem.get(2);
                float y1 = elem.get(3);
                float x2 = elem.get(4);
                float y2 = elem.get(5);
                float left = x1<x2?x1:x2;
                float right = x1<x2?x2:x1;
                float top = y1<y2?y1:y2;
                float bottom = y1<y2?y2:y1;
                if((left<=x)&&(x<=right)&&(top<=y)&&(y<=bottom)){
                    if(!eraseAct){
                        model.setSelected(true);
                    }

                    ArrayList<Float> shape = new ArrayList<Float>();
                        list.remove(i);
                        if (!isErase) {
                            shape.add((float) tool);
                            shape.add((float) color);

                            //scale
                            if(scaleFactor==1){
                                scaleFactorOld=1;
                            }else if(Math.abs(scaleFactorOld - scaleFactor)>0.01){
                                float factor = scaleFactor-scaleFactorOld;
                                if(factor>1){
                                    factor=1;
                                }else if(factor<-0.5){
                                    factor= (float) -0.5;
                                }
                                // Log.d("scalefactor----->factor", ""+factor);
                                bottom *= (1+ factor);
                                right *= (1+ factor);

                                scaleFactorOld = scaleFactor;
                            }

                            shape.add(left);
                            shape.add(top);
                            shape.add(right);
                            shape.add(bottom);
                            list.add(shape);
                        }
                    if(isMove){
                        move(x, y);
                    }else {
                        canvas.drawColor(Color.WHITE);
                        redraw();
                    }
                    return 1;
                }
            }else if(tool==4){ //line
                float x1 = elem.get(2);
                float y1 = elem.get(3);
                float x2 = elem.get(4);
                float y2 = elem.get(5);
                float left = x1<x2?x1:x2;
                float right = x1<x2?x2:x1;
                float top = y1<y2?y1:y2;
                float bottom = y1<y2?y2:y1;
                //y=ax+c
                float a = (y2-y1)/(x2-x1);
                float c = y1-a*x1;
                if((left<=x)&&(x<=right)&&(a<6)){
                    float y_expect = a*x + c;
                    float epsilon = 0;
                    if(isMove){
                        epsilon = 70;
                    }else{
                        epsilon = 30;
                    }
                    if(((y_expect-epsilon)<=y)&&(y<=(y_expect+epsilon))){
                        if(!eraseAct){
                            model.setSelected(true);
                        }

                        ArrayList<Float> shape = new ArrayList<Float>();
                            list.remove(i);
                            if (!isErase) {
                                shape.add((float) tool);
                                shape.add((float) color);

                                //scale
                                if(scaleFactor==1){
                                    scaleFactorOld=1;
                                }else if(Math.abs(scaleFactorOld - scaleFactor)>0.01){
                                    float factor = scaleFactor-scaleFactorOld;
                                    if(factor>1){
                                        factor=1;
                                    }else if(factor<-0.5){
                                        factor= (float) -0.5;
                                    }

                                    if((Math.abs(y1-y2)<=40)&&(Math.abs(x1-x2)<=40)&&(factor<0)){
                                        //skip
                                    }else if(x1>x2){
                                        x1 *= (1+ factor);
                                    }else{
                                        x2 *= (1+ factor);
                                    }

                                    y1=a*x1+c;
                                    y2=a*x2+c;

                                    scaleFactorOld = scaleFactor;
                                }
                                shape.add(x1);
                                shape.add(y1);
                                shape.add(x2);
                                shape.add(y2);
                                list.add(shape);
                            }
                        if(isMove){
                            move(x, y);
                        }else {
                            canvas.drawColor(Color.WHITE);
                            redraw();
                        }
                        return 1;
                    }
                }else if((top<=y)&&(y<=bottom)) {
                    float x_expect = (y - c)/a;
                    float epsilon = 0;
                    if (isMove) {
                        epsilon = 100;
                    } else {
                        epsilon = 40;
                    }
                    if (((x_expect - epsilon) <= x) && (x <= (x_expect + epsilon))) {
                        if(!eraseAct){
                            model.setSelected(true);
                        }

                        ArrayList<Float> shape = new ArrayList<Float>();
                        list.remove(i);
                        if (!isErase) {
                            shape.add((float) tool);
                            shape.add((float) color);

                            //scale
                            if (scaleFactor == 1) {
                                scaleFactorOld = 1;
                            } else if (Math.abs(scaleFactorOld - scaleFactor) > 0.01) {
                                float factor = scaleFactor - scaleFactorOld;
                                if (factor > 1) {
                                    factor = 1;
                                } else if (factor < -0.5) {
                                    factor = (float) -0.5;
                                }

                                if ((Math.abs(y1 - y2) <= 60) && (Math.abs(x1 - x2) <= 60) && (factor < 0)) {
                                    //skip
                                } else if (y1 > y2) {
                                    y1 *= (1 + factor/30);
                                } else {
                                    y2 *= (1 + factor/30);
                                }

                                x1 = (y1-c)/a;
                                x2 = (y2-c)/a;

                                scaleFactorOld = scaleFactor;
                            }
                            shape.add(x1);
                            shape.add(y1);
                            shape.add(x2);
                            shape.add(y2);
                            list.add(shape);
                        }
                        if (isMove) {
                            move(x, y);
                        } else {
                            canvas.drawColor(Color.WHITE);
                            redraw();
                        }
                        return 1;
                    }
                }
            }
        }
        //either touch down or move on blank undo selected
        model.setSelected(false);
        return 0;
    }

    public void draw(float x, float y){
        int color = model.getColor();
        canvas.drawColor(Color.WHITE);
        redraw();
        paint.setColor(color);
        if(model.getTool()==2){//draw rect
            canvas.drawRect(start_x, start_y, x, y, paint);
            imageView.setImageBitmap(bitmap);
        } else if(model.getTool()==3){//draw circle
            float dx = Math.abs(x-start_x);
            float dy = Math.abs(y-start_y);
            float radius = (float) Math.sqrt(dx*dx+dy*dy);
            canvas.drawCircle(start_x, start_y, radius, paint);
            imageView.setImageBitmap(bitmap);
        } else if(model.getTool()==4){//draw line
            paint.setStrokeWidth(8);
            canvas.drawLine(start_x, start_y, x, y, paint);
            imageView.setImageBitmap(bitmap);
        }
    }

    public void redraw(){
        ArrayList<ArrayList<Float>> list = model.getList();
        for(ArrayList<Float> elem: list){
            int tool = elem.get(0).intValue();
            int color = elem.get(1).intValue();
            paint.setColor(color);
            if(tool == 2){//rectangle
                canvas.drawRect(elem.get(2), elem.get(3), elem.get(4), elem.get(5), paint);
                imageView.setImageBitmap(bitmap);
            }else if(tool == 3){//circle
                canvas.drawCircle(elem.get(2), elem.get(3), elem.get(4), paint);
                imageView.setImageBitmap(bitmap);
            }else if(tool == 4){//line
                paint.setStrokeWidth(8);
                canvas.drawLine(elem.get(2), elem.get(3), elem.get(4), elem.get(5), paint);
                imageView.setImageBitmap(bitmap);
            }
        }
        //activate view change
        imageView.setImageBitmap(bitmap);
    }

    public void addShape(float x, float y){
        ArrayList<ArrayList<Float>> shapelist = model.getList();
        ArrayList<Float> shape = new ArrayList<Float>();
        if(model.getTool()==3){
            //circle
            float dx = Math.abs(x-start_x);
            float dy = Math.abs(y-start_y);
            float radius = (float) Math.sqrt(dx*dx+dy*dy);
            shape.add((float) 3.0);
            shape.add((float) model.getColor());
            shape.add(start_x);
            shape.add(start_y);
            shape.add(radius);
            shapelist.add(shape);

        }else if(model.getTool()==2){
            //rect
            shape.add((float) 2.0);
            shape.add((float) model.getColor());
            shape.add(start_x);
            shape.add(start_y);
            shape.add(x);
            shape.add(y);
            shapelist.add(shape);
        }else if(model.getTool()==4){
            //line
            shape.add((float) 4.0);
            shape.add((float) model.getColor());
            shape.add(start_x);
            shape.add(start_y);
            shape.add(x);
            shape.add(y);
            shapelist.add(shape);
        }
        model.setList(shapelist);
    }



    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        @Override
        public boolean onScale(ScaleGestureDetector detector) {
            scaleFactor *= detector.getScaleFactor();
            float tmp = Math.min(scaleFactor, 2.7f);
            scaleFactor = Math.max(0.05f, tmp);
            invalidate();
            return true;
        }
        @Override
        public void onScaleEnd(ScaleGestureDetector detector){
            scaleFactor = 1.f;

        }

    }


    public int getW() {
        return w;
    }

    public void setW(int w) {
        this.w = w;
    }

    public int getH() {
        return h;
    }

    public void setH(int h) {
        this.h = h;
    }

    public ImageView getImageView() {
        return imageView;
    }

    public void setImageView(ImageView imageView) {
        this.imageView = imageView;
    }

    @Override
    public void update(Observable o, Object arg)
    {
        if(model.getSelectColor()==1){
            return;
        }
        if(model.isSelected()){
            changeColor(model.getColor());
        }
    }
}
