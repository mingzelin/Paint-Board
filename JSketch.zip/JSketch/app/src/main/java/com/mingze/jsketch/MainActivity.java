package com.mingze.jsketch;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.annotation.DrawableRes;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
{
    Model model;
    Board board;
    Tool tool;
    int orientation;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        orientation = getResources().getConfiguration().orientation;
        if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
            // landscape
            setContentView(R.layout.activity_main_land);
        } else {
            // portrait
            setContentView(R.layout.activity_main);
        }

        model = new Model();
        //default colour
        model.setColor(getResources().getColor(R.color.sky, null));
        // Setup views
        tool = new Tool(this, model,
                (ImageView) findViewById(R.id.select),
                (ImageView) findViewById(R.id.eraser),
                (ImageView) findViewById(R.id.rectangle),
                (ImageView) findViewById(R.id.circle),
                (ImageView) findViewById(R.id.line),
                (LinearLayout) findViewById(R.id.sky),
                (LinearLayout) findViewById(R.id.lemon),
                (LinearLayout) findViewById(R.id.tomato),
                (LinearLayout) findViewById(R.id.orange),
                (LinearLayout) findViewById(R.id.greenyellow),
                (ImageView) findViewById(R.id.palette),
                (View) findViewById(R.id.selectedcolor));
        ImageView imageView = (ImageView) findViewById(R.id.paintboard);
        board = new Board(this, model, imageView);
        model.initObservers();
        model.addObserver(board);
        model.addObserver(tool);
        tool.setSkycolor(getResources().getColor(R.color.sky, null));
        tool.setLemoncolor(getResources().getColor(R.color.lemon, null));
        tool.setTomatocolor(getResources().getColor(R.color.tomato, null));
        tool.setOrangecolor(getResources().getColor(R.color.orange, null));
        tool.setGreenyellowcolor(getResources().getColor(R.color.greenyellow, null));
        tool.setPalettecolor(-1);
        //toggle effect
        int drId = -1;
        if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
            // landscape
            drId = getResources().getIdentifier("solidborder", "drawable",getApplicationContext().getPackageName());
        } else {
            // portrait
            drId = getResources().getIdentifier("solidborder_por", "drawable",getApplicationContext().getPackageName());
        }

        Drawable dr = getResources().getDrawable(drId, null);
        tool.setToggle(dr);
        drId = getResources().getIdentifier("white", "drawable",getApplicationContext().getPackageName());
        dr = getResources().getDrawable(drId, null);
        tool.setWhitedr(dr);
        tool.setAct(this);


    }


    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        int height = findViewById(R.id.paintboardparent).getHeight();
        int width = findViewById(R.id.paintboardparent).getWidth();
        board.setCanvas(height, width);
        board.redraw();
    }


    //popup window
    public void pop(){
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        View popup = inflater.inflate(R.layout.popup, null);
        //focusable -> outside will dismiss popup window
        boolean focus = true;
        final PopupWindow window = new PopupWindow(popup, LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT, focus);
        window.showAtLocation(findViewById(android.R.id.content), Gravity.CENTER, 0, 0);
        ImageView iv1 = (ImageView) popup.findViewById(R.id.darkred);
        iv1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                model.setColor(getResources().getColor(R.color.darkred, null));
                model.setSelectColor(2);
                window.dismiss();
            }
        });

        ImageView iv2 = (ImageView) popup.findViewById(R.id.lightred);
        iv2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                model.setColor(getResources().getColor(R.color.lightred, null));
                model.setSelectColor(2);
                window.dismiss();
            }
        });

        ImageView iv3 = (ImageView) popup.findViewById(R.id.darkorange);
        iv3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                model.setColor(getResources().getColor(R.color.darkorange, null));
                model.setSelectColor(2);
                window.dismiss();
            }
        });

        ImageView iv4 = (ImageView) popup.findViewById(R.id.darkyellow);
        iv4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                model.setColor(getResources().getColor(R.color.darkyellow, null));
                model.setSelectColor(2);
                window.dismiss();
            }
        });
        ImageView iv5 = (ImageView) popup.findViewById(R.id.lightyellow);
        iv5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                model.setColor(getResources().getColor(R.color.lightyellow, null));
                model.setSelectColor(2);
                window.dismiss();
            }
        });
        ImageView iv6 = (ImageView) popup.findViewById(R.id.darkgreen);
        iv6.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                model.setColor(getResources().getColor(R.color.darkgreen, null));
                model.setSelectColor(2);
                window.dismiss();
            }
        });
        ImageView iv7 = (ImageView) popup.findViewById(R.id.darkblue);
        iv7.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                model.setColor(getResources().getColor(R.color.darkblue, null));
                model.setSelectColor(2);
                window.dismiss();
            }
        });
        ImageView iv8 = (ImageView) popup.findViewById(R.id.purple);
        iv8.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                model.setColor(getResources().getColor(R.color.purple, null));
                model.setSelectColor(2);
                window.dismiss();
            }
        });
        ImageView iv9 = (ImageView) popup.findViewById(R.id.pink);
        iv9.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                model.setColor(getResources().getColor(R.color.pink, null));
                model.setSelectColor(2);
                window.dismiss();
            }
        });
        ImageView iv10 = (ImageView) popup.findViewById(R.id.lightgrey);
        iv10.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                model.setColor(getResources().getColor(R.color.lightgrey, null));
                model.setSelectColor(2);
                window.dismiss();
            }
        });
        ImageView iv11 = (ImageView) popup.findViewById(R.id.grey);
        iv11.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                model.setColor(getResources().getColor(R.color.grey, null));
                model.setSelectColor(2);
                window.dismiss();
            }
        });
        ImageView iv12 = (ImageView) popup.findViewById(R.id.black);
        iv12.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                model.setColor(getResources().getColor(R.color.black, null));
                model.setSelectColor(2);
                window.dismiss();
            }
        });
    }

    public float[] toArray(ArrayList<Float> arraylist){
        int length = arraylist.size();
        float[] result = new float[length];
        for(int i = 0; i<length; i++){
            result[i] = arraylist.get(i);
        }
        return result;
    }

    public ArrayList<Float> toArrayList(float[] list){
        int length = list.length;
        ArrayList<Float> result = new ArrayList<Float>();
        for(int i = 0; i<length; i++){
            result.add(list[i]);
        }
        return result;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState)
    {
        super.onSaveInstanceState(outState);
        outState.putInt("color", model.getColor());
        outState.putInt("tool", model.getTool());
        //put all the shape on store
        ArrayList<ArrayList<Float>> list = model.getList();
        int length = list.size();
        for(int i=0; i<length; i++){

            ArrayList<Float> arraylist = model.getList().get(i);
            int height = findViewById(R.id.paintboardparent).getHeight();
            int width = findViewById(R.id.paintboardparent).getWidth();
            int epsilon1 = 140;
            int epsilon2 = 20;
            if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
                // landscape -> portrait
                if(arraylist.get(0)==3){//circle
                    float xold = arraylist.get(2);
                    float yold = arraylist.get(3);
                    float ynew = xold;
                    float xnew = height - yold + epsilon1;

                    arraylist.set(2, xnew);
                    arraylist.set(3, ynew);
                }else{ //rect or line
                    float x1old = arraylist.get(2);
                    float y1old = arraylist.get(3);
                    float y1new = x1old;
                    float x1new = height - y1old + epsilon1;
                    arraylist.set(2, x1new);
                    arraylist.set(3, y1new);

                    float x2old = arraylist.get(4);
                    float y2old = arraylist.get(5);
                    float y2new = x2old;
                    float x2new = height - y2old + epsilon1;
                    arraylist.set(4, x2new);
                    arraylist.set(5, y2new);
                }
            } else {
                // portrait -> landscape
                if(arraylist.get(0)==3) {//circle
                    float xold = arraylist.get(2);
                    float yold = arraylist.get(3);
                    float xnew = yold;
                    float ynew = width - xold - epsilon2;
                    arraylist.set(2, xnew);
                    arraylist.set(3, ynew);
                }else { //rect or line
                    float x1old = arraylist.get(2);
                    float y1old = arraylist.get(3);
                    float x1new = y1old;
                    float y1new = width - x1old - epsilon2;
                    arraylist.set(2, x1new);
                    arraylist.set(3, y1new);

                    float x2old = arraylist.get(4);
                    float y2old = arraylist.get(5);
                    float x2new = y2old;
                    float y2new = width - x2old - epsilon2;
                    arraylist.set(4, x2new);
                    arraylist.set(5, y2new);
                }
            }
            outState.putFloatArray("shape" + i, toArray(arraylist));
        }
        outState.putInt("shapes-length", length);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState)
    {
        super.onRestoreInstanceState(savedInstanceState);
        model.setColor(savedInstanceState.getInt("color"));
        model.setSelectColor(2);
        tool.toggle(savedInstanceState.getInt("tool"));
        //take all the shape from store

        int length = savedInstanceState.getInt("shapes-length");
        for(int i=0; i<length; i++){
            ArrayList<Float> elem = toArrayList(savedInstanceState.getFloatArray("shape" +i));
            model.addList(elem);
        }
    }
}
