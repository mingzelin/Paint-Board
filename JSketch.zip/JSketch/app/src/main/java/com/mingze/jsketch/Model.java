package com.mingze.jsketch;
import android.graphics.Color;
import android.util.Log;

import java.util.Observable;
import java.util.Observer;
import java.util.ArrayList;

public class Model extends Observable
{
    private int mCounter;
    private int tool;
    private int color;
    private int selectColor;
    private ArrayList<ArrayList<Float>> list;
    private boolean selected;

    Model() {
        mCounter = 0;
        tool = -1;
        selectColor=0;
        // indicates which tool is being used.
        // select = 0, eraser = 1, rectangle = 2, circle = 3, line = 4;
        color=0;
        list = new ArrayList<ArrayList<Float>>();
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
        setChanged();
        notifyObservers();

    }


    public int getTool() {
        return tool;
    }

    public void setTool(int tool) {
        this.tool = tool;
    }

    public ArrayList<ArrayList<Float>> getList() {
        return list;
    }

    public void addList(ArrayList<Float> member){
        list.add(member);
    }

    public void setList(ArrayList<ArrayList<Float>> list) {
        this.list = list;
    }

    public void initObservers()
    {
        setChanged();
        notifyObservers();
    }





    public boolean isSelected() {
        return selected;
    }


    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public int getSelectColor() {
        return selectColor;
    }

    //2: change colour reflector to model colour
    //1: change colour to selected colour
    public void setSelectColor(int sc) {
        if(sc>=1){
            this.selectColor = sc;
            setChanged();
            notifyObservers();
            selectColor=0;
        }
    }

    @Override
    public synchronized void deleteObserver(Observer o)
    {
        super.deleteObserver(o);
    }


    @Override
    public synchronized void addObserver(Observer o)
    {
        super.addObserver(o);
    }


    @Override
    public synchronized void deleteObservers()
    {
        super.deleteObservers();
    }

    @Override
    public void notifyObservers()
    {
        super.notifyObservers();
    }
}
