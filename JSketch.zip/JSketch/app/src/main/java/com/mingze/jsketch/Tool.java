package com.mingze.jsketch;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;


public class Tool extends View implements Observer
{
    private Model model;
    private ImageView select;
    private ImageView eraser;
    private ImageView rectangle;
    private ImageView circle;
    private ImageView line;
    private LinearLayout sky;
    private LinearLayout lemon;
    private LinearLayout tomato;
    private LinearLayout orange;
    private LinearLayout greenyellow;
    private ImageView palette;
    private View selectedView;
    private int skycolor;
    private int lemoncolor;
    private int tomatocolor;
    private int orangecolor;
    private int greenyellowcolor;
    private int palettecolor;
    private Drawable toggle;
    private Drawable whitedr;
    private MainActivity act;
    public Tool(Context context, Model m, ImageView s, ImageView e, ImageView r, ImageView c, ImageView l, LinearLayout sk, LinearLayout le, LinearLayout to, LinearLayout or, LinearLayout gr, ImageView pa, View sv)
    {
        super(context);
        model = m;
        model.addObserver(this);
        select = s;
        eraser = e;
        rectangle = r;
        circle = c;
        line = l;
        sky = sk;
        lemon = le;
        tomato = to;
        orange = or;
        greenyellow = gr;
        palette = pa;
        selectedView = sv;

        selectedView.setBackgroundColor(model.getColor());

        // Create controller for button
        // select = 0, eraser = 1, rectangle = 2, circle = 3, line = l;
        select.setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                //add toggle effect

                toggle(0);
                model.setSelected(false);
            }
        });
        eraser.setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

                toggle(1);
                model.setSelected(false);
            }
        });
        rectangle.setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

                toggle(2);
                model.setSelected(false);
            }
        });
        circle.setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                toggle(3);
                model.setSelected(false);
            }
        });
        line.setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                toggle(4);
                model.setSelected(false);
            }
        });

        sky.setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                model.setColor(getSkycolor());
                selectedView.setBackgroundColor(model.getColor());

            }
        });

        lemon.setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                model.setColor(getLemoncolor());
                selectedView.setBackgroundColor(model.getColor());
            }
        });

        tomato.setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                model.setColor(getTomatocolor());
                selectedView.setBackgroundColor(model.getColor());
            }
        });

        orange.setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                model.setColor(getOrangecolor());
                selectedView.setBackgroundColor(model.getColor());
            }
        });

        greenyellow.setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                model.setColor(getGreenyellowcolor());
                selectedView.setBackgroundColor(model.getColor());
            }
        });

        palette.setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                act.pop();

            }
        });



    }

    public void toggle(int index){
        //select = 0, erase =1, rect = 2, circle=3, line =4
        if(model.getTool()==index){
            return;
        }
        if(model.getTool()==0){
            select.setBackground(whitedr);
        }else if(model.getTool()==1){
            eraser.setBackground(whitedr);
        }else if(model.getTool()==2){
            rectangle.setBackground(whitedr);
        }else if(model.getTool()==3){
            circle.setBackground(whitedr);
        }else if(model.getTool()==4){
            line.setBackground(whitedr);
        }

        if(index==0){
            select.setBackground(toggle);
        }else if(index==1){
            eraser.setBackground(toggle);
        }else if(index==2){
            rectangle.setBackground(toggle);
        }else if(index==3){
            circle.setBackground(toggle);
        }else if(index==4){
            line.setBackground(toggle);
        }
        model.setTool(index);
    }


    public int getSkycolor() {
        return skycolor;
    }

    public void setSkycolor(int skycolor) {
        this.skycolor = skycolor;
    }

    public int getLemoncolor() {
        return lemoncolor;
    }

    public void setLemoncolor(int lemoncolor) {
        this.lemoncolor = lemoncolor;
    }

    public int getTomatocolor() {
        return tomatocolor;
    }

    public void setTomatocolor(int tomatocolor) {
        this.tomatocolor = tomatocolor;
    }

    public int getOrangecolor() {
        return orangecolor;
    }

    public void setOrangecolor(int orangecolor) {
        this.orangecolor = orangecolor;
    }

    public int getGreenyellowcolor() {
        return greenyellowcolor;
    }

    public void setGreenyellowcolor(int greenyellowcolor) {
        this.greenyellowcolor = greenyellowcolor;
    }

    public int getPalettecolor() {
        return palettecolor;
    }

    public void setPalettecolor(int palettecolor) {
        this.palettecolor = palettecolor;
    }

    public Drawable getToggle() {
        return toggle;
    }

    public void setToggle(Drawable toggle) {
        this.toggle = toggle;
    }


    public void setWhitedr(Drawable whitedr) {
        this.whitedr = whitedr;
    }

    public MainActivity getAct() {
        return act;
    }

    public void setAct(MainActivity act) {
        this.act = act;
    }

    @Override
    public void update(Observable o, Object arg)
    {
        if(model.getSelectColor()<1){
            return;
        }else if(model.getSelectColor()==1){
            ArrayList<ArrayList<Float>> list = model.getList();
            int length = list.size()-1;
            selectedView.setBackgroundColor(list.get(length).get(1).intValue());
        }else if(model.getSelectColor()==2){
            selectedView.setBackgroundColor(model.getColor());
        }
    }
}
