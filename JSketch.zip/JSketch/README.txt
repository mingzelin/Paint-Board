made by Mingze Lin
Student ID: 20655470
user id: m59lin
email: m59lin@edu.uwaterloo.ca

APK file is at location:
m59lin/a4/JSketch/app-debug.apk

MAC
openjdk 12.0.2 2019-07-16
OpenJDK Runtime Environment AdoptOpenJDK (build 12.0.2+10)
OpenJDK 64-Bit Server VM AdoptOpenJDK (build 12.0.2+10, mixed mode, sharing)

TESTED ON ANDROID MACHINE:
Google Pixel C borrowed from DC lib (Android Version 8.1.0)

API:
My program supports machines that has api27, api28, api29.

Note:
Please note that when draw circle, mine program draw from the centre of the circle.
This is approved by professor Jeff Avery on PIAZZA POST @279


Enhancement:
use pinch-to-zoom to resize a single shape
(i.e. select the shape, then pinch-in or pinch-out to change the size of that shape).
